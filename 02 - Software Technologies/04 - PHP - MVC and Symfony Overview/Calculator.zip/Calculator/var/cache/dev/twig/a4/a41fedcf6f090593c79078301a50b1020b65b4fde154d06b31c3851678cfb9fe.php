<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_5c157cb5f5d9c5a5e39667ad7a4a03b51ff555bbc9140bfa1b8e571bfd2be3da extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c9b1f325b63ddf514d949a425025b0efcc7e9f7b2683c321494e91de7d4299ca = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c9b1f325b63ddf514d949a425025b0efcc7e9f7b2683c321494e91de7d4299ca->enter($__internal_c9b1f325b63ddf514d949a425025b0efcc7e9f7b2683c321494e91de7d4299ca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c9b1f325b63ddf514d949a425025b0efcc7e9f7b2683c321494e91de7d4299ca->leave($__internal_c9b1f325b63ddf514d949a425025b0efcc7e9f7b2683c321494e91de7d4299ca_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_826c8f08a5ac134d933213bae5c33f740861ceacad14b80652d209508962448f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_826c8f08a5ac134d933213bae5c33f740861ceacad14b80652d209508962448f->enter($__internal_826c8f08a5ac134d933213bae5c33f740861ceacad14b80652d209508962448f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_826c8f08a5ac134d933213bae5c33f740861ceacad14b80652d209508962448f->leave($__internal_826c8f08a5ac134d933213bae5c33f740861ceacad14b80652d209508962448f_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_5ae6026d47793ec49789ffd4064dd3139beca21347b36eccd4157d29f243c02d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5ae6026d47793ec49789ffd4064dd3139beca21347b36eccd4157d29f243c02d->enter($__internal_5ae6026d47793ec49789ffd4064dd3139beca21347b36eccd4157d29f243c02d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_5ae6026d47793ec49789ffd4064dd3139beca21347b36eccd4157d29f243c02d->leave($__internal_5ae6026d47793ec49789ffd4064dd3139beca21347b36eccd4157d29f243c02d_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_b864d7ed8b1e10f83512086e7aca7d2e181b65fe62bca2d1f421e5a584265c6e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b864d7ed8b1e10f83512086e7aca7d2e181b65fe62bca2d1f421e5a584265c6e->enter($__internal_b864d7ed8b1e10f83512086e7aca7d2e181b65fe62bca2d1f421e5a584265c6e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_b864d7ed8b1e10f83512086e7aca7d2e181b65fe62bca2d1f421e5a584265c6e->leave($__internal_b864d7ed8b1e10f83512086e7aca7d2e181b65fe62bca2d1f421e5a584265c6e_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
";
    }
}
